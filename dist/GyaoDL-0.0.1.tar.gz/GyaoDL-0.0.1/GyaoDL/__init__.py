from .gyaodl import *

__copyright__ = '(c) 2021 xpadev-net https://xpadev.net'
__version__ = '0.0.1'
__license__ = 'MIT'
__author__ = 'xpadev-net'
__author_email__ = 'xpadev@gmail.com'
__url__ = 'https://github.com/xpadev-net/gyaodl'

__all__ = [GyaoDL]
