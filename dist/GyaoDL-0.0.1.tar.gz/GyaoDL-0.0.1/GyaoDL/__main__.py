from GyaoDL import GyaoDL
import sys
if __name__ == "__main__":
    gyaoid = sys.argv[1]
    path = sys.argv[2]
    gyaodl = GyaoDL(gyaoid, path)
